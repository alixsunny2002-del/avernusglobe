	
// Wait until window.load so all external libs (Earth, Swiper) are ready
  window.addEventListener('load', async () => {
    // --- sanity check Earth lib
    if (typeof Earth === 'undefined') {
      console.error('Earth library not found. Fix the path to miniature.earth.core.js.');
      alert('Error: Earth library not loaded. See console.');
      return;
    }

    const myearth = new Earth('myearth', {
      location: { lat: 20, lng: 20 },
      light: 'none',
      transparent: true,
      autoRotate: true,
      autoRotateSpeed: 1.2,
      autoRotateStart: 2000,
      mapImage: 'hologram/hologram-map-01.svg'
    });
    console.log('myearth created', myearth);

    // countries map (country-level center points)


    const countries = {
      // 🌍 Europe
      "Europe": { lat: 54.5260, lng: 15.2551 },
      "Belgium": { lat: 50.8503, lng: 4.3517 },
      "Switzerland": { lat: 46.8182, lng: 8.2275 },
      "Germany": { lat: 51.1657, lng: 10.4515 },
      "United Kingdom": { lat: 55.3781, lng: -3.4360 },
      "Netherlands": { lat: 52.1326, lng: 5.2913 },
      "Denmark": { lat: 56.2639, lng: 9.5018 },
      "Poland": { lat: 51.9194, lng: 19.1451 },
      "Hungary": { lat: 47.1625, lng: 19.5033 },
      "France": { lat: 46.6034, lng: 1.8883 },
      "Spain": { lat: 40.4637, lng: -3.7492 },
      "Italy": { lat: 41.8719, lng: 12.5674 },
      "Greece": { lat: 39.0742, lng: 21.8243 },
      "Portugal": { lat: 39.3999, lng: -8.2245 },

      // 🌏 Asia
      "Asia": { lat: 34.0479, lng: 100.6197 },
      "South Korea": { lat: 35.9078, lng: 127.7669 },
      "India": { lat: 20.5937, lng: 78.9629 },

      // 🌎 North America
      "North America": { lat: 54.5260, lng: -105.2551 },
      "USA": { lat: 37.0902, lng: -95.7129 },

      // 🌍 Africa
      "Africa": { lat: 8.7832, lng: 34.5085 },
      "Egypt": { lat: 26.8206, lng: 30.8025 }
    };


    // create lowercase lookup to be forgiving about casing
    const countriesLookup = {};
    for (const k in countries) {
      countriesLookup[k.trim().toLowerCase()] = countries[k];
    }

    // init Swiper AFTER everything's loaded
    const swiper = new Swiper('#vertical-swiper', {
      direction: 'vertical',
      slidesPerView: 5,
      centeredSlides: true,
      spaceBetween: 12,
      keyboard: { enabled: true },
      loop: true
    });

    // highlight helper (if Earth supports addOverlay)
    let highlightMarker = null;
    function highlightCountry(loc) {
      try {
        if (!myearth || typeof myearth.addOverlay !== 'function') {
          console.warn('addOverlay not available on myearth');
          return;
        }
        if (highlightMarker && typeof highlightMarker.remove === 'function') highlightMarker.remove();
        highlightMarker = myearth.addOverlay({
          location: loc,
          mesh: 'glow',
          color: 'rgba(0,255,150,0.8)',
        //   scale: 3
        });
      } catch (err) {
        console.error('highlightCountry error', err);
      }
    }

    // helper to wait until goTo is available (polling)
    function waitForGoTo(timeout = 3000) {
      return new Promise((resolve, reject) => {
        const start = Date.now();
        (function check() {
          if (typeof myearth.goTo === 'function') return resolve(true);
          if (Date.now() - start > timeout) return reject(new Error('myearth.goTo not ready'));
          setTimeout(check, 100);
        })();
      });
    }

    // click handler with .closest so inner <span> clicks work
  document.addEventListener('click', async (e) => {
  const link = e.target.closest('.regions');
  if (!link) return;

  e.preventDefault();
  const raw = String(link.dataset.country || '').trim().toLowerCase();
  console.log('Clicked country raw:', raw);

  const loc = countriesLookup[raw];
  if (!loc) {
    console.warn('No coordinates found for:', raw);
    return;
  }

  try {
    await waitForGoTo(3000);
    // zoom + fly
    myearth.goTo(loc, { duration: 2000, zoom: 1.8 });
    highlightCountry(loc);

    // shift globe left
    document.getElementById('myearth').classList.add('shift-left');
  } catch (err) {
    console.error('Error moving globe:', err);
  }

// to bring the globe back
  document.querySelector('#swiper-back').addEventListener('click', () => {
  document.getElementById('myearth').classList.remove('shift-left');
  myearth.goTo({ lat: 20, lng: 20 }, { duration: 2000, zoom: 1.2 });
  console.log("clicked back button");

});

});

    // OPTIONAL: if you want the globe to move when the center slide changes:
    // (uncomment to enable)

    swiper.on('slideChangeTransitionEnd', async () => {
      const activeEl = swiper.slides[swiper.activeIndex];
      const regionEl = activeEl.querySelector('.regions');
      if (!regionEl) return;
      const raw = String(regionEl.dataset.country || '').trim().toLowerCase();
      const loc = countriesLookup[raw];
      if (!loc) return;
      try { await waitForGoTo(3000); myearth.goTo(loc, { duration: 1200, zoom: 1.1 }); highlightCountry(loc); } catch(e){ console.warn(e); }
    });

    console.log('Setup complete. Click a slide to fly the globe.');
  }); // window.load
	
    
    
    // swiper

	document.addEventListener('DOMContentLoaded', function() {
	  const swiper = new Swiper('#vertical-swiper', {
	    direction: 'vertical',
	    slidesPerView: 5,       // show 5 slides at once
	    centeredSlides: true,   // keep active slide in center
	    spaceBetween: 12,
	    mousewheel: true,
	    // pagination: {
	    //   el: '.swiper-pagination',
	    //   clickable: true,
	    // },
	    keyboard: { enabled: true },
	    loop: true, // optional: infinite loop
	    autoplay: {
	      delay: 100000, // Delay between transitions in milliseconds
	    },
	  });
	});